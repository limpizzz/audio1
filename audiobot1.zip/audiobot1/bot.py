import telebot
from speechkit import text_to_speech
bot = telebot.TeleBot("7155252450:AAHX6ggkZEYLIC4hVF1bhiVgzvKundlycK0")
@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, "Добро пожаловать в бота, который озвучивает текст!Чтобы озвучить текст,используй команду /tts")
@bot.message_handler(commands=['tts'])
def tts1(message):
    bot.send_message(message.chat.id, "Введи текст:")
    def tts2(message):
        text = message.text
        # Вызываем функцию и получаем результат
        success, response = text_to_speech(text)

        if success:
            bot.send_voice(message.chat.id, response)
        else:
            # Если возникла ошибка, выводим сообщение об ошибке
            bot.send_message(message.chat.id, "Ошибка")

    bot.register_next_step_handler(message, tts2)
bot.polling()
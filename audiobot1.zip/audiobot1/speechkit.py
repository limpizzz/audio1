import requests


def text_to_speech(text: str):
    # Токен, Folder_id для доступа к Yandex SpeechKit
    iam_token = "t1.9euelZqRy5mTkJGUy4nLlcuKns_Lju3rnpWajZmMmcqTisnKyJPOjYmVlpnl8_cTGgVP-e9TSwMP_t3z91NIAk_571NLAw_-zef1656Vmp6Ml5yOmY-PjpSdlIzOlpyK7_zF656Vmp6Ml5yOmY-PjpSdlIzOlpyKveuelZrMzZCVzI2Tk5mVk4qNno-XzrXehpzRnJCSj4qLmtGLmdKckJKPioua0pKai56bnoue0oye.ksQFL8gz0GgIkdCX2LNKMJB7lVd4czL5Kymq_45Tv73OiIYb6jtF4tUs9K7cJ_6eJNxAuYmI2NzAuKbbSE3cAg"
    folder_id = 'b1gb1o17aj4e22s1c3m4'

    # Аутентификация через IAM-токен
    headers = {
        'Authorization': f'Bearer {iam_token}',
    }
    data = {
        'text': text,  # текст, который нужно преобразовать в голосовое сообщение
        'lang': 'ru-RU',  # язык текста - русский
        'voice': 'filipp',  # голос Филлипа
        'folderId': folder_id,
    }
    # Выполняем запрос
    response = requests.post('https://tts.api.cloud.yandex.net/speech/v1/tts:synthesize', headers=headers, data=data)

    if response.status_code == 200:
        return True, response.content  # Возвращаем голосовое сообщение
    else:
        return False, "При запросе в SpeechKit возникла ошибка"




